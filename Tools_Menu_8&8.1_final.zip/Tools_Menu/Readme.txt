This will install a menu to your context(right click) menu. items include regedit, open cmd here(normal and admin) show/hide known file types, show/hide hidden files/folders, and open admin powershell here.

steps
1. Run Tools.bat as admin
2. Follow what it says
3. If icons dont show up reboot or restart explorer

Changelog
v0.2 - added open powershell as admin here, fixed open cmd as admin here, no longer need ele.exe and the e.cmd file
v0.3 - able to remove the restart explorer.bat file thanks to coldbloc
v0.4 - added power menu. normal has lock, logoff, restart, restart with boot options, and shut down. the second has all of the first but sleep, hibernate, and switch user.
v0.5 - fixed an issue in the hidden files vbs(thanks LEDelete for pointing it out), fixed missing icon folder copy command in install script (thanks trm96 for pointing that out) should fix icons not showing up